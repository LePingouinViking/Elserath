RP — La Fureur des Titans
================================

1) Ajoute le fichier à ton dépôt GitHub:
   - Chemin: rp/fracture-la-fureur-des-titans.html
   - Méthode: GitHub → Add file → Upload files → uploade ce ZIP, ou crée le fichier et colle le HTML

2) Vérifie la page:
   - URL: https://lasaintepioche.fr/rp/fracture-la-fureur-des-titans.html

3) Sur la page, poste un premier message dans Giscus:
   - Cela créera automatiquement un fil de discussion dans la catégorie 'RP' de ton repo GitHub.

4) (Optionnel) Ajoute un lien depuis forum.html (section 'Fracture du Ciel'):
   <li><a href="/rp/fracture-la-fureur-des-titans.html">La Fureur des Titans</a></li>

Remarques:
- Giscus est configuré en mapping=pathname pour obtenir 1 fil par page RP.
- Le thème suit la préférence du navigateur (clair/sombre).
